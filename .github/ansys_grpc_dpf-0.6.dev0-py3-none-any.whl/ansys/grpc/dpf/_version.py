"""ansys-grpc-dpf python protocol version"""
__version__ = '0.6.dev0'  # major.minor.patch
