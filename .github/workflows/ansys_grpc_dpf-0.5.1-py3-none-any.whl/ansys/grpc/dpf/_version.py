"""ansys-grpc-dpf python protocol version"""
__version__ = '0.5.1'  # major.minor.patch
