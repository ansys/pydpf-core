"""Version for ansys-dpf-gate"""
# major, minor, patch
version_info = 0, 1, 1
__ansys_version__ = "222"

# Nice string for the version
__version__ = ".".join(map(str, version_info))
