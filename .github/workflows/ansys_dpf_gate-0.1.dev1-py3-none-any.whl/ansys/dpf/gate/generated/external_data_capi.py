import ctypes
from ansys.dpf.gate import utils
from ansys.dpf.gate import errors
from ansys.dpf.gate.generated import capi
from ansys.dpf.gate.generated import external_data_abstract_api

#-------------------------------------------------------------------------------
# ExternalData
#-------------------------------------------------------------------------------

class ExternalDataCAPI(external_data_abstract_api.ExternalDataAbstractAPI):

	@staticmethod
	def external_data_wrap(external_data, deleter):
		res = capi.dll.ExternalData_wrap(external_data, deleter)
		return res

	@staticmethod
	def external_data_free(var1):
		res = capi.dll.ExternalData_free(var1._internal_obj)
		return res

	@staticmethod
	def external_data_get(external_data):
		res = capi.dll.ExternalData_get(external_data._internal_obj)
		return res

