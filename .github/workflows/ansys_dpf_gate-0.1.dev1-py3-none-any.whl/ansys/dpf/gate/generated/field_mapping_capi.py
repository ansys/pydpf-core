import ctypes
from ansys.dpf.gate import utils
from ansys.dpf.gate import errors
from ansys.dpf.gate.generated import capi
from ansys.dpf.gate.generated import field_mapping_abstract_api

#-------------------------------------------------------------------------------
# FieldMapping
#-------------------------------------------------------------------------------

class FieldMappingCAPI(field_mapping_abstract_api.FieldMappingAbstractAPI):

	@staticmethod
	def mapping_delete(obj):
		errorSize = ctypes.c_int(0)
		sError = ctypes.c_wchar_p()
		res = capi.dll.Mapping_Delete(obj._internal_obj, ctypes.byref(utils.to_int32(errorSize)), ctypes.byref(sError))
		if errorSize.value != 0:
			raise errors.DPFServerException(sError.value)
		return res

	@staticmethod
	def mapping_map(obj, in_field):
		errorSize = ctypes.c_int(0)
		sError = ctypes.c_wchar_p()
		res = capi.dll.Mapping_Map(obj._internal_obj, in_field._internal_obj, ctypes.byref(utils.to_int32(errorSize)), ctypes.byref(sError))
		if errorSize.value != 0:
			raise errors.DPFServerException(sError.value)
		return res

