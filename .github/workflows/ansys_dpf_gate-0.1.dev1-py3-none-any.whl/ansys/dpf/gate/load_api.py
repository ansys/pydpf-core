import os
import ctypes
from ansys.dpf.gate.generated import capi
from ansys.dpf.gate import utils
from ansys.dpf.core._version import (
    __ansys_version__
)

def _unified_installer_path_if_exists():
    ANSYS_INSTALL = os.environ.get("AWP_ROOT" + str(__ansys_version__), None)
    return ANSYS_INSTALL

def _get_api_path_from_installer_or_package(ANSYS_PATH: str, ISPOSIX: bool):
    if ANSYS_PATH is not None:
        dpf_inner_path = ""
        if not ISPOSIX:
            dpf_inner_path = os.path.join("aisol", "bin", "winx64")
        else:
            dpf_inner_path = os.path.join("aisol", "dll", "linx64")
        path = os.path.join(ANSYS_PATH, dpf_inner_path) # should work from the installer
    else: 
        # should work from the gatebin package
        _try_use_gatebin()
        from ansys.dpf import gatebin
        path = os.path.abspath(gatebin.__path__._path[0])
    return path

def _try_use_gatebin():
    try:
        from ansys.dpf import gatebin
    except ModuleNotFoundError:
        raise ModuleNotFoundError(
            "To use ansys-dpf-gate as a standalone client API "
            "(without Ansys installer), install ansys-dpf-gatebin "
            "with :\n pip install ansys-dpf-gatebin."
        )

def load_client_api():
    ISPOSIX = os.name == "posix"
    name = "DPFClientAPI.dll"
    if ISPOSIX:
        name = "libDPFClientAPI.so"
        
    ANSYS_PATH = _unified_installer_path_if_exists()
    path = _get_api_path_from_installer_or_package(ANSYS_PATH, ISPOSIX)
    
    dpf_client_api_path = os.path.join(path, name)
    capi.load_api(dpf_client_api_path)
    return dpf_client_api_path

def load_grpc_client():
    path = ""
    ISPOSIX = os.name == "posix"
    name = "Ans.Dpf.GrpcClient"
    if ISPOSIX:
        name = "libAns.Dpf.GrpcClient"
    
    ANSYS_PATH = _unified_installer_path_if_exists()
    path = _get_api_path_from_installer_or_package(ANSYS_PATH, ISPOSIX)
    
    # PATH should be set only on Windows and only if working 
    # from the installer because of runtime dependencies 
    # on libcrypto and libssl
    previous_path = ""
    if not ISPOSIX and ANSYS_PATH is not None:
        previous_path = os.getenv("PATH","")
        os.environ["PATH"]=path+";"+previous_path

    grpc_client_api_path = os.path.join(path, name)
    try:
        utils.data_processing_core_load_api(grpc_client_api_path, "remote")
    except Exception as e:
        if not ISPOSIX:
            os.environ["PATH"] = previous_path
        raise e
        
    # reset of PATH
    if not ISPOSIX and ANSYS_PATH is not None:
        os.environ["PATH"] = previous_path

    return grpc_client_api_path

