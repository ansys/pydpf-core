import os
import ctypes
from ansys.dpf.gate.generated import capi
from ansys.dpf.gate import utils, errors
from ansys.dpf.gate._version import (
    __ansys_version__
)

def _find_outdated_ansys_version(arg: str):
    arg_to_compute = str(arg)
    ver_check = 221 # 221 or lower versions are not supported
    c = 'v'
    char_pos = [pos for pos, char in enumerate(arg_to_compute) if char == c]
    # check if len after char is > 3
    for pos in char_pos:
        i = pos + 1
        n = i + 3
        str_test = arg_to_compute[i:n]
        # check if 3 characters after char is int
        if len(str_test) >= 3:
            if str_test.isdigit():
                check = int(str_test)
                if check > int(__ansys_version__):
                    continue
                if check <= ver_check:
                    return True
    return False

def _unified_installer_path_if_exists():
    ANSYS_INSTALL = os.environ.get("AWP_ROOT" + str(__ansys_version__), None)
    return ANSYS_INSTALL

def _get_api_path_from_installer_or_package(ANSYS_PATH: str, ISPOSIX: bool):
    is_ansys_version_old = _find_outdated_ansys_version(ANSYS_PATH)
    gatebin_found = _try_use_gatebin()
    dpf_client_found = False
    if gatebin_found and not is_ansys_version_old: 
        # should work from the gatebin package
        from ansys.dpf import gatebin
        path = os.path.abspath(gatebin.__path__._path[0])
        dpf_client_found = True
    else:
        if ANSYS_PATH is not None:
            dpf_inner_path = ""
            if not ISPOSIX:
                dpf_inner_path = os.path.join("aisol", "bin", "winx64")
            else:
                dpf_inner_path = os.path.join("aisol", "dll", "linx64")
            path = os.path.join(ANSYS_PATH, dpf_inner_path) # should work from the installer
            if os.path.isdir(path):
                dpf_client_found = True
    if not dpf_client_found and not is_ansys_version_old:
        raise ModuleNotFoundError(
            "To use ansys-dpf-gate as a client API "
            "install ansys-dpf-gatebin "
            "with :\n pip install ansys-dpf-gatebin."
        ) 
    return path

def _try_use_gatebin():
    try:
        from ansys.dpf import gatebin
        return True
    except ModuleNotFoundError:
        return False
    except ImportError:
        return False
    except Exception as e:
        raise e
        return False

def _try_load_api(path):
    try:
        capi.load_api(path)
    except Exception as e:
        b_module_not_found = False
        if isinstance(e, OSError):
            if hasattr(e, 'winerror'): # if on Windows, we can check the error code
                if e.winerror == 126:
                    b_module_not_found = True
            else: # Linux case, no error code
                b_module_not_found = True
        if not b_module_not_found:
            raise e
        else:
            raise errors.DpfVersionNotSupported("4.0")

def load_client_api(ansys_path = None):
    ISPOSIX = os.name == "posix"
    name = "DPFClientAPI.dll"
    if ISPOSIX:
        name = "libDPFClientAPI.so"
    
    ANSYS_PATH = ansys_path
    if ANSYS_PATH is None:
        ANSYS_PATH = _unified_installer_path_if_exists()
    path = _get_api_path_from_installer_or_package(ANSYS_PATH, ISPOSIX)
    
    dpf_client_api_path = os.path.join(path, name)
    _try_load_api(path=dpf_client_api_path)
    return dpf_client_api_path

def load_grpc_client(ansys_path = None):
    path = ""
    ISPOSIX = os.name == "posix"
    name = "Ans.Dpf.GrpcClient"
    if ISPOSIX:
        name = "libAns.Dpf.GrpcClient"

    ANSYS_PATH = ansys_path
    if ANSYS_PATH is None:
        ANSYS_PATH = _unified_installer_path_if_exists()
    path = _get_api_path_from_installer_or_package(ANSYS_PATH, ISPOSIX)
    
    # PATH should be set only on Windows and only if working 
    # from the installer because of runtime dependencies 
    # on libcrypto and libssl
    previous_path = ""
    if not ISPOSIX and ANSYS_PATH is not None:
        previous_path = os.getenv("PATH","")
        os.environ["PATH"]=path+";"+previous_path

    grpc_client_api_path = os.path.join(path, name)
    try:
        utils.data_processing_core_load_api(grpc_client_api_path, "remote")
    except Exception as e:
        if not ISPOSIX:
            os.environ["PATH"] = previous_path
        raise e
        
    # reset of PATH
    if not ISPOSIX and ANSYS_PATH is not None:
        os.environ["PATH"] = previous_path

    return grpc_client_api_path

