"""ansys-grpc-dpf python protocol version"""
__version__ = '0.5.dev1'  # major.minor.patch
