"""Version for ansys-dpf-gate"""
# major, minor, patch
version_info = 0, 3, "0.dev0"
__ansys_version__ = "232"

# Nice string for the version
__version__ = ".".join(map(str, version_info))
