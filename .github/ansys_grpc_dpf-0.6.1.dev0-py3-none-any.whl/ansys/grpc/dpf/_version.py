"""ansys-grpc-dpf python protocol version"""
__version__ = '0.6.1dev0'  # major.minor.patch
