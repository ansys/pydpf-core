"""ansys-grpc-dpf python protocol version"""
__version__ = '0.7.0dev0'  # major.minor.patch
