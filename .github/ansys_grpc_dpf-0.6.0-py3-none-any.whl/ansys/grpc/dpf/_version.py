"""ansys-grpc-dpf python protocol version"""
__version__ = '0.6.0'  # major.minor.patch
